<?php
	
include ('../koneksi.php');
	
	$file_size = $_FILES["zip_file"]["size"];
	$new_size = $file_size/1024;  

	 function GetImageExtension($imagetype)
   	 {
       if(empty($imagetype)) return false;
       switch($imagetype)
       {
           case 'application/zip': return '.zip';
           case 'application/rar': return '.rar';
          
           default: return false;
       }
     }
  if (($new_size > 900)){     
  echo "FILE UPLOAD OVER 900 KB";
  }
 else{
if (!empty($_FILES["zip_file"]["name"])) {
	
$nama_ketua_tim = $_POST['nama_ketua_tim'];
$no_telp_ketua = $_POST['no_telp_ketua'];
$email_ketua_tim = $_POST['email_ketua_tim'];
$ttl_ketua_tim = $_POST['ttl_ketua_tim'];
$nama_anggota_1 = $_POST['nama_anggota_1'];
$nama_anggota_2 = $_POST['nama_anggota_2'];
$asal_sekolah = $_POST['asal_sekolah'];
$alamat_sekolah = $_POST['alamat_sekolah'];
$nama_guru_pebimbing = $_POST['nama_guru_pebimbing'];
$no_telp_guru_pebimbing = $_POST['no_telp_guru_pebimbing'];
$file_name=$_FILES["zip_file"]["name"];
$temp_name=$_FILES["zip_file"]["tmp_name"];
$imgtype=$_FILES["zip_file"]["type"];
$path = $_FILES['zip_file']['name'];
$ext = pathinfo($path, PATHINFO_EXTENSION);
$imagename=date("d-m-Y")."-".time().".".$ext;
$target_path = "images/".$imagename;
$user = $_POST['user'];
$pass = $_POST['pass'];



	if(move_uploaded_file($temp_name, $target_path)) {
	mysqli_query($con,"INSERT INTO registration VALUES('$nama_ketua_tim','$no_telp_ketua','$email_ketua_tim','$ttl_ketua_tim','$nama_anggota_1','$nama_anggota_2','$asal_sekolah','$alamat_sekolah','$nama_guru_pebimbing','$no_telp_guru_pebimbing','$target_path','0','$user','$pass')");
?>
<script>
		alert('successfully uploaded');
		window.location.href='../index.php?success';
        </script>
		<?php
	}
else
{
echo "error";
}

	}
	else
{
echo "error";
}
}
?>