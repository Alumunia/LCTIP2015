
    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#page-top">ICT IPB</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                   
				   <li class="page-scroll <?php echo $daftar_Peserta;?>">
                        <a href="dashboard.php">Daftar Peserta</a>
                    </li>
					<li class="page-scroll  <?php echo $sponsor;?>">
                        <a href="dashboard_sponsor.php">Sponsor</a>
                    </li>
					<li class="page-scroll"  <?php echo $daftar_Peserta;?>>
                        <a href="dashboard_sponsor.php">Soal</a>
                    </li>
					
				   
                    <li class="page-scroll">
                        <a href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>