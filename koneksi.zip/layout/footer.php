 <!-- Footer -->
    <footer class="text-center">
        <div class="footer-above" style="margin-bottom:0px">
           
                <div class="row">
					<?php
			
$no=1;
$value=1;
$number=1;
$result = mysqli_query($con,"SELECT * FROM sponsor") 
or die(mysqli_error());  


// output data of each row
while($row = mysqli_fetch_assoc( $result )) {
  
?>
           
   <!---IKLAN 1---->
         <div class="col-md-2">
		
       	<?php
			$query=mysqli_query($con,"SELECT * FROM sponsor WHERE number=$no")
			or die(mysqli_error());
			while($row = mysqli_fetch_assoc($query)){
			?>
			
		<a href="<?php echo $row['link'];?>" target="_blank">	<img  width="200px" src="process/<?php echo $row['images_path'];?>" alt="http://W3Schools.com" height="150px" width="80px" style="padding-bottom:10px"></a>
		
			<?php } ?>                     
		
			
			</div>
	<!--------THE END OF IKLAN 1---->
<?php $no++;}  ?>
               
                </div>
         
        </div>
     
    </footer>