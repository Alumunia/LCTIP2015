<?php
include ('koneksi.php');

session_start();
date_default_timezone_set('Asia/Jakarta');
if(empty($_SESSION['id'])){
}
else{
$id=$_SESSION['id'];
$query=mysqli_query($con,"SELECT * FROM registration WHERE user='$id'");

$query = mysqli_fetch_array($query);
$nama_ketua_tim=$query['nama_ketua_tim'];
$nama_anggota_1=$query['nama_anggota_1'];
$nama_anggota_2=$query['nama_anggota_2'];
$asal_sekolah=$query['asal_sekolah'];
$alamat_sekolah=$query['alamat_sekolah'];
$nama_guru_pebimbing=$query['nama_guru_pebimbing'];
$no_telp_guru_pebimbing=$query['no_telp_guru_pebimbing'];
$status=$query['status'];



}

$index="actives";
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>LCT</title>

    <!-- Bootstrap Core CSS - Uses Bootswatch Flatly Theme: http://bootswatch.com/flatly/ -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/freelancer.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body id="page-top" class="index" style="background-image:url('assets/images/bg-1.png');">

 <?php
 
 include('layout/nav.php');

 
 
 ?>

    <!-- Header -->
	

   

    <!-- Contact Section -->
    <section id="contact" style="padding-top:130px">
        <div class="container">
		<?php if (isset($_GET['success'])){?>
		<div id="alert_message"  class="alert alert-info alert-dismissable">
		<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
		<strong>Thanks For Registration  </strong> Now you have to wait untill our team validate your registration form :)
		</div>
		<?php } else if (isset($_GET['error'])){?>
		<div id="alert_message"  class="alert alert-warning alert-dismissable">
		<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
		<strong>Sorry </strong> But your account is not validate yet
		</div>
		
		<?php } else if (isset($_GET['failed'])){?>
		<div id="alert_message"  class="alert alert-danger alert-dismissable">
		<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
		<strong>Ooopss</strong> You not registration yet
		</div>
		
		<?php }?>
		
				<script>
				window.setTimeout(function() {
  $("#alert_message").fadeTo(500, 0).slideUp(500, function(){
    $(this).remove(); 
  });
}, 3000);
</script>
            <div class="row">
                <div class="col-lg-8 text-center">
				<?php if (isset($_SESSION['id'])) {?>
				<div class="well well-lg">
				
				<h2>Pengumuman! </h2>
				<br>
				<br>
				<p>Kuis akan di buka pada tanggal 12 agustus 2019<br>
				Terima Kasih sudah mendaftar</p>
					
				
				
				
				
				
				
				
				</div>
               <?php } else{ ?>
				 <iframe width="560" height="315" src="https://www.youtube.com/embed/Lt0WP9ZBNiY" frameborder="0" allowfullscreen></iframe>
				
				<?php } ?>
			   </div>
				
				 <div class="col-lg-4 text-center">
				 <?php if (isset($_SESSION['id'])) {?>
				
				 <div style="BACKGROUND-COLOR: WHITE";>
				  <h5>Profile</h5>
                    <!-- To configure the contact form email address, go to mail/contact_me.php and update the email address in the PHP file on line 19. -->
                    <!-- The form should work on most web servers, but if the form is not working you may need to configure your web server differently. -->
                   <div class="text-left">
				   <label>Nama Ketua Tim&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp <?php echo $nama_ketua_tim;?></label><br>
				   <label>Nama anggota 1&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp  <?php echo $nama_anggota_1;?></label><br>
				   <label>Nama anggota 2&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp  <?php echo $nama_anggota_2;?></label><br>
				   <label>Asal Sekolah&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo $asal_sekolah;?></label><br>
				   <label>Alamat Sekolah&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp  <?php echo $alamat_sekolah;?></label><br>
				   <label>Nama Pebimbing&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp <?php echo $nama_guru_pebimbing;?></label><br>
				   <label>telp Pebimbing&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp <?php echo $no_telp_guru_pebimbing;?></label><br>
				   <label>status&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp   <?php
	if ($status ==0 ) {echo "Belum Terverifikasi";}
	else {echo "terverifikasi";}
				 ?></label><br>
				   </div>
                </div>
				
				
               <?php } else{ ?>
                  <div class="col-lg-8 col-lg-offset-2" style="BACKGROUND-COLOR: WHITE";>
				  <h5>Form Login</h5>
                    <!-- To configure the contact form email address, go to mail/contact_me.php and update the email address in the PHP file on line 19. -->
                    <!-- The form should work on most web servers, but if the form is not working you may need to configure your web server differently. -->
                    <form role="form" method="post" enctype="multipart/form-data" action="process/form_input_1.php" >
                        <div class="row control-group">
                            <div class="form-group col-xs-12 floating-label-form-group controls">
                                <label>Username</label>
                                <input type="text" class="form-control" required placeholder="Username" name="user" required data-validation-required-message="silahkan masukkan username"/>
                                <p class="help-block text-danger"></p>
                            </div>
                        </div>
                        <div class="row control-group">
                            <div class="form-group col-xs-12 floating-label-form-group controls">
                                <label>password</label>
                                <input type="text" class="form-control" placeholder="Password" name="pass" required data-validation-required-message="silahkan masukkan login">
                                <p class="help-block text-danger"></p>
                            </div>
                        </div>
                      
                        <br>
                        <div id="success"></div>
                        <div class="row">
                            <div class="form-group col-xs-12">
                                <button type="submit" class="btn btn-info">Login</button>
                            </div>
                        </div>
                    </form>
                </div>
				<?php } ?>
                </div>
            </div>
			   
          
        </div>
    </section>

   <?php include('layout/footer.php')?>

    <!-- Scroll to Top Button (Only visible on small and extra-small screen sizes) -->
    <div class="scroll-top page-scroll visible-xs visible-sm">
        <a class="btn btn-primary" href="#page-top">
            <i class="fa fa-chevron-up"></i>
        </a>
    </div>

    <!-- Portfolio Modals -->


    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
    <script src="js/classie.js"></script>
    <script src="js/cbpAnimatedHeader.js"></script>

    <!-- Contact Form JavaScript -->
 <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>
    

    <!-- Custom Theme JavaScript -->
    <script src="js/freelancer.js"></script>

</body>

</html>
