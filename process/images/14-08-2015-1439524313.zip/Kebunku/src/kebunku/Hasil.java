package kebunku;

public class Hasil {
    // jenis = 0 => Madu, jenis = 1 => Buah
    private boolean jenis;
    private int jumlah;
    private int harga;
   
}
