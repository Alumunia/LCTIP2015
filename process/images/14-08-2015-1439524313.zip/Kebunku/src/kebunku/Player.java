package kebunku;

public class Player {
    private static String nama;
    private int jumUang;
    private int jumTanaman;
    private int jumBuah;
    private int jumMadu;
    private Tanaman tanaman;
    
    public void beliTanaman() {

    }
    
    public void jualHasil() {
        
    }
    
    public void menyiram() {
        
    }
    public void memanen(){
        
    }
    
}
