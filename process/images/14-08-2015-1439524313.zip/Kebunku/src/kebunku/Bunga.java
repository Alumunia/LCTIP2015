package kebunku;

public class Bunga extends Tanaman {
    
    public void hasilkanMadu() {
        System.out.println("Madu dihasilkan");
    }
    
    
   
}
