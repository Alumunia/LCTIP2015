package kebunku;

public class Tanaman {
    private String nama;
    private int usia;
    private int harga;
    private float X;
    private float Y;
    
    public void tumbuh() {
        System.out.println("Tanaman tumbuh");
    }
    
}
