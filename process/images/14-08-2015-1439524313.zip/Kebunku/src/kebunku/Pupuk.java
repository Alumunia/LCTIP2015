package kebunku;


public class Pupuk {
    private int hargaPupuk;
    private int jumlahPupuk;

    
}
