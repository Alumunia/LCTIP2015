package kebunku;

public class Pohon extends Tanaman {
    
    public void hasilkanBuah() {
        System.out.println("Buah dihasilkan");
    }
}
